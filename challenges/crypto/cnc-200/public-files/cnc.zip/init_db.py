#!/usr/bin/python3
from index import db
db.create_all()