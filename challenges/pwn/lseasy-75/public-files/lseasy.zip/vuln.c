#include <stdio.h>

void main()
{
	printf("The content of the current folder is : \n");
	system("ls -l");
}
